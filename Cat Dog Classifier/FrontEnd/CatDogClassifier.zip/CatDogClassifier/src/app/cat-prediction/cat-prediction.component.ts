import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-cat-prediction',
  templateUrl: './cat-prediction.component.html',
  styleUrls: ['./cat-prediction.component.css']
})
export class CatPredictionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
