import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CatPredictionComponent } from './cat-prediction.component';

describe('CatPredictionComponent', () => {
  let component: CatPredictionComponent;
  let fixture: ComponentFixture<CatPredictionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CatPredictionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CatPredictionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
