import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CatPredictionComponent } from './cat-prediction/cat-prediction.component';
import { DogPredictionComponent } from './dog-prediction/dog-prediction.component';

class ImageSnippet {
  constructor(public src: string, public file: File) { }
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'CatDogClassifier';

  selectedFile: ImageSnippet;
  imageNotUploaded: Boolean = true;
  apiCalled: Boolean = false;

  constructor(private http: HttpClient, private dialog: MatDialog) { }

  processFile(imageInput: any) {
    const file: File = imageInput.files[0];
    const reader = new FileReader();

    reader.addEventListener('load', (event: any) => {
      this.imageNotUploaded = false;
      document.getElementById('upload-label').textContent = imageInput.files[0].name;
      this.selectedFile = new ImageSnippet(event.target.result, file);
      document.getElementById('imageResult').setAttribute('src', this.selectedFile.src);

    });

    reader.readAsDataURL(file);
  }

  startPrediction() {
    this.apiCalled = true;
    this.http.post<any>('http://localhost:5000/predict', this.selectedFile.file  ).subscribe(
      (data) => {
        console.log(data);
        if (data['class'] === 'cat') {
          this.dialog.open(CatPredictionComponent);
        }
        else {
          this.dialog.open(DogPredictionComponent);
        }
        
        this.apiCalled = false;
        document.getElementById('imageResult').setAttribute('src', '#');
        document.getElementById('upload-label').textContent = "No File Choosen";
        this.imageNotUploaded = true;
        (<HTMLInputElement>document.getElementById('upload')).value = null;
      }
    )
  }
}
