import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DogPredictionComponent } from './dog-prediction.component';

describe('DogPredictionComponent', () => {
  let component: DogPredictionComponent;
  let fixture: ComponentFixture<DogPredictionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DogPredictionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DogPredictionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
