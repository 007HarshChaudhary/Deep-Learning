import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dog-prediction',
  templateUrl: './dog-prediction.component.html',
  styleUrls: ['./dog-prediction.component.css']
})
export class DogPredictionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
